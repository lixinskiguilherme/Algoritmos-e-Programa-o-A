// Escreva um algoritmo leia pelo teclado um valor inteiro chamado x, e ent�o mostre na tela todos os n�meros de 0 a 100 que s�o divis�veis por x.

#include <stdio.h>

main(){
	int i, x;
	printf("Digite um numero para verificar quais numeros de 0 a 100 sao divisiveis por ele: ");
	scanf("%i", &x);
	if(x==0){
		printf("Divisao por zero NAO e permitida!");
	}
	else
			for(i=0; i<=100; i++){
			if(i% x==0){
				printf("%i e divisivel por %i\n", i, x);
			}
		}
	getch();
}

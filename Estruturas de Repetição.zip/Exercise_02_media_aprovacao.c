#include <stdio.h>

int main() {
    float nota1, nota2, nota3, media;
    int i, x;

    printf("Digite o numero de alunos: ");
    scanf("%i", &x);

    for(i = 1; i <= x; i++) {
        printf("\nAluno %d\n", i);
        printf("Digite a nota 01: ");
        scanf("%f", &nota1);
        printf("Digite a nota 02: ");
        scanf("%f", &nota2);    
        printf("Digite a nota 03: ");
        scanf("%f", &nota3);

        media = (nota1 + nota2 + nota3) / 3;
        printf("A media do aluno e de: %.2f\n", media);

        if(media >= 6) {
            printf("APROVADO\n");
        } else {
            printf("REPROVADO\n");
        }
    }
    getch();
}

#include <stdio.h>

main(){
	float n_eleitores, n_vt_brancos, n_vt_nulos, n_vt_validos, p_v_b, p_v_n, p_v_v, vabst;
	printf("Informe o numero de eleitores: ");
	scanf("%f", &n_eleitores);
	printf("Informe o numero de votos brancos: ");
	scanf("%f", &n_vt_brancos);
	printf("Informe o numero de votos nulos: ");
	scanf("%f", &n_vt_nulos);
	printf("Informe o numero de votos validos: ");
	scanf("%f", &n_vt_validos);
	p_v_b = (n_vt_brancos/n_eleitores)*100;
	p_v_n = (n_vt_nulos/n_eleitores)*100;
	p_v_v = (n_vt_validos/n_eleitores)*100;
	vabst = 100 - p_v_b - p_v_n - p_v_v;
	printf("%.2f %% da populacao votou em branco nesta eleicao\n",p_v_b);
	printf("%.2f %% da populacao anulou seu voto nesta eleicao\n",p_v_n);
	printf("%.2f %% da populacao tiveram seus votos validos nesta eleicao\n",p_v_v);
	printf("%.2f %% da populacao abstiveram-se nesta eleicao\n",vabst);
	getch();
}

#include <stdio.h>

main(){
	float salario, percentual, vreajuste, nsalario;
	printf("Informe o valor do salario atual: ");
	scanf("%f", &salario);
	printf("Informe o percentual de reajuste: ");
	scanf("%f", &percentual);
	vreajuste = salario*(percentual/100);
	printf("O valor do reajuste salarial e de: %.2f\n", vreajuste);
	nsalario = salario+vreajuste;
	printf("O seu salario passara a ser de: %.2f\n", nsalario);
	printf("Congractularions");
	getch();
}

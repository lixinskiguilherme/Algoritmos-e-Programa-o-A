#include <stdio.h>

main(){
	int minutos, segundos, multiplicacao;
	printf("Digite o numero de minutos que deseja converter: ");
	scanf("%i", &minutos);
	multiplicacao = minutos*60;
	printf("O valor informado corresponde a: %i segundos", multiplicacao);
	getch();
	
	
}

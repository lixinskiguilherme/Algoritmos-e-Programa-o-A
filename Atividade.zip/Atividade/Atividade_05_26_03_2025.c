#include <stdio.h>

main(){
	float valor, percentual, vlrdesconto, vlrliquido;
	printf("Digite o valor do produto: ");
	scanf("%f", &valor);
	printf("Informe o percentual de desconto: ");
	scanf("%f", &percentual);
	vlrdesconto = (valor*percentual)/100;
	printf("O valor do desconto em reais e de: %.2f\n",vlrdesconto);
	vlrliquido = valor-vlrdesconto;
	printf("O valor liquido do produto e de: %.2f",vlrliquido);
	
	
	getch(); 
	
	
	
}

#include <stdio.h>

main(){
	float cidade, populacao, area, densidade;
	printf("Informe a populacao da cidade: ");
	scanf("%f", &populacao);
	printf("Informe a area: ");
	scanf("%f", &area);
	densidade = populacao/area;
	printf("A densidade populacional e de: %f", densidade);
	getch();
}

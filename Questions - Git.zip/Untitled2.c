#include <stdio.h>

int main() {
    // Declara��o de vari�veis
    double comprimento, largura, altura, volume;

    // Entrada de dados
    printf ("Digite o comprimento da caixa: ");
    scanf (comprimento;
    cout << "Digite a largura da caixa: ";
    cin >> largura;
    cout << "Digite a altura da caixa: ";
    cin >> altura;

    // C�lculo do volume
    volume = comprimento * largura * altura;

    // Exibi��o do resultado
    cout << "O volume da caixa �: " << volume << " unidades c�bicas." << endl;

    return 0;
}

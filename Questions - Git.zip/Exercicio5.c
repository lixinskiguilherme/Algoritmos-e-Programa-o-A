#include <stdio.h>

main(){
 	float n1, n2, soma, multiplicacao, divisao, subtracao;
 	printf("digite n1:");
 	scanf("%f",&n1);
 	printf("digite n2:");
 	scanf("%f",&n2);
 	soma = n1 + n2;
 	printf("soma = %f\n", soma);
 	divisao = n1/n2;
 	printf("divisao de n1 por n2 = %f\n",divisao);
 	multiplicacao = n1*n2;
 	printf("multiplicacao de n1 por n2 = %f\n",multiplicacao);
 	subtracao = multiplicacao/n2;
 	printf("subtracao do resultado da multiplicacao por n2 = %f\n",subtracao);
	getch();
	
}

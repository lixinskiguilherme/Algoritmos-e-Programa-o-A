#include <stdio.h>

main(){
	float raio, area;
	printf("Digite o raio do circulo:");
	scanf("%f",&raio);
	area = (raio*raio)*3.14159;
	printf("area = %f",area);
	getch();
}

#include <stdio.h>

main(){
    double c, f;
	printf("Digite a temperatura em Celcius:");
	scanf("%lf", &c);
	
	f = f-(32/9); 
	
	printf("O valor correspondente em Fhrenheit: %lf",f);
          
     getch();
}

#include <stdio.h>

main(){
	float base, altura, area;
	printf("Digite a base: ");
	scanf("%f\n", &base);
	printf("Digite a altura: ")
	scanf("%f\n", &altura);
	area = base * altura;
	printf("area = %f",area);
	getch();
	
	
	
	
	
	
}

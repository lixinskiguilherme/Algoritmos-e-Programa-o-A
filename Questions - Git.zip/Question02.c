#include <stdio.h>

main(){
    double c, f;
	printf("Digite a temperatura em Celcius:");
	scanf("%lf", &c);
	
	f = 9*(c/5)+32; 
	
	printf("O valor correspondente em Fhrenheit: %lf",f);
          
     getch();
}

#include <stdio.h>

main(){
	// Declarar as vari�veis
	float volume, comprimento, largura, altura; 
 	printf("Calcular Vol. Retangular\n");
 	printf("Informe o comprimento: \n");
 	scanf("%f", &comprimento);
 	printf("Informe a largura: \n");
 	scanf("%f", &largura);
 	printf("Informe a altura: \n");
 	scanf("%f", &altura);
 	volume = ((comprimento*largura)*largura);
 	printf("O valor do Vol. Retancular e de: %f\n", volume);
 	printf("Congractulations");
 	getch();
}

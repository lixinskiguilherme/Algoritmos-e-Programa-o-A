#include <stdio.h>

main(){
	float lado, area;
	printf("Digite o lado do triangulo:");
	scanf("%f",&lado);
	area = lado*lado*1.732/4;
	printf("Area = %f\n",area);
	getch();
}


#include <stdio.h>

main(){
	float valorcompra, pdesconto, vdesconto, vfinal;
	printf("Digite o valor da compra: ");
	scanf("%f", &valorcompra);
	if(valorcompra<=300){
		pdesconto = 10;
	}
	else {
		pdesconto = 15;
	}
	vdesconto = valorcompra*pdesconto/100;
	vfinal = valorcompra - vdesconto;
	printf("Valor da compra: %.2f\n", valorcompra);
	printf("%% Desconto: %.2f\n", pdesconto);
	printf("Valor desconto: %.2f\n", vdesconto);
	printf("Valor final: %.2f\n", vfinal);
	getch();
	
	
}

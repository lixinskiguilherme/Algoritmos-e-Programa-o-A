#include <stdio.h>

main(){
	float n1, desconto, vf;
	printf("Digite o valor da compra: ");
	scanf("%f", &n1);
	if(n1<=300){
		printf("O percentual de desconto e de 10%%\n");
		desconto=n1*0.10;
		printf("O valor do desconto e de %f", desconto);
		vf=n1-desconto;
		printf("O valor final e de %f",vf);
	}
	else if(n1>300);{
		printf("O percentual de desconto e de 15%%\n");
		desconto=n1*0.15;
		printf("O valor do desconto e de %f", desconto);
		vf=n1-desconto;
		printf("O valor final e de %f",vf);
	}
	getch();
	
	
}

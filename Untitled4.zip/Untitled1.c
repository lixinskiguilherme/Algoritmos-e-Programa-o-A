#include <stdio.h>

main(){
	float n1, n2, n3, n4, media;
	printf("Digite n1': ");
	scanf("%f", &n1);
	printf("Digite n2': ");
	scanf("%f", &n2);
	printf("Digite n3': ");
	scanf("%f", &n3);
	printf("Digite n4': ");
	scanf("%f", &n4);
	media=(n1+n2+n3+n4)/4;
	printf("Media = %f\n", media);
	if(n1<media){
		printf("N1 menor que a media\n");
	}
	if(n2<media){
		printf("N2 menor que a media\n");
	}
	if(n3<media){
		printf("N3 menor que a media\n");
	}
	if(n4<media){
		printf("N4 menor que a media\n");
	}
	getch();
	
	
}

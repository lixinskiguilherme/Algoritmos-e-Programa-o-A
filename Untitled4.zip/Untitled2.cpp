#include <stdio.h>

main(){
	int n1;
	printf("Digite n1': ");
	scanf("%i", &n1);
	if(n1%6==3){
		printf("Condicao Verdadeira");
	}
	else{
		printf("Condicao Falsa");
	}
	
	
	
	
	
}

#include <stdio.h>
#include <conio.h>

main(){
	int val;
	printf("Digite um numero: ");
	scanf("%d", &val);
	
	if(val > 0 && !(val%2==0)){
		printf("O numero e impar e positivo!\n");
		}
	
}

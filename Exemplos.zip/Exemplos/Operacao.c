#include <stdio.h>

main(){
	float num1, num2, resultado;
	int op;
	printf("Digite dois numeros: ");
	scanf("%f%f", &num1, &num2);
	printf("\nEscolha a operacao:\n1.soma\n2.subtracao\n3.multiplicacao\n4.divisao\n5.potencia\n\nescolha: ");
	scanf("%d", &op);
	if(op ==1){
		resultado = num1+num2;
		printf("Resultado da soma: %f",resultado);
	}
	else if(op ==2){
		resultado = num1-num2;
		printf("Resultado da subtracao e: %f",resultado);
	}
	else if(op ==3){
		resultado = num1*num2;
		printf("Resultado da multiplicacao e: %f",resultado);
	}
	else if(op ==4){
		resultado = num1/num2;
		printf("Resultado da divisao e: %f",resultado);
	}
	else if(op ==5){
		resultado = pow(num1,num2);
		printf("Resultado da potencia e: %f",resultado);
	}
	
	
	getch();
	
	
}

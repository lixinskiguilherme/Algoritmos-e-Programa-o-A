#include <stdio.h>

main(){
	int num;
	printf("Digite um numero: ");
	scanf("%d", &num);
	if(num % 2==0){
		printf("\nO numero e divisivel por 2");
	}
	if(num % 4==0){
		printf("\nO numero e divisivel por 4");
	}
	if(num % 8==0){
		printf("\nO numero e divisivel por 8");
}
	
	
	getch();
	
	
}

#include <stdio.h>
#include <stdbool.h>

main(){
	int i;
	i = 10;
	while(i>=1){
		printf("i vale %i\n",i);
		
		i--;
	}
	

}

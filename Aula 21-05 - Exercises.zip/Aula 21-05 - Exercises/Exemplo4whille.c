#include <stdio.h>
#include <stdbool.h>

main(){
	int i;
	i = 1;
	while(i<=10){
		printf("i vale %i\n",i);
		
		i++;
	}
	

}

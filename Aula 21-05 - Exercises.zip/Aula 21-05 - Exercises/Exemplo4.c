#include <stdio.h>
#include <stdbool.h>

main(){
	int i, j, k;
	for( i =0; i<20; i++){
		printf ("i vale %i\n", i);
		for(j = 0; j<4; j++){
			printf("	j vale %i\n", j);
			for(k = 0; k<2; k++){
				printf("		k vale %i\n", k);
			}
		}
	}
	
}

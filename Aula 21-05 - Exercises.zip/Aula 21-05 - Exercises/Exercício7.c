/*Escreva um algoritmo para calcular o fatorial de um n�mero.*/

#include <stdio.h>

int main() {
    int n, i;
    float res;
    res=1;
    printf("Digite um numero: ");
    scanf("%i", &n);
    for(i=5; i>1; i--){
    	res = i * res;
    }
    printf("Fatorial de %i: %.0f", n, res);
}

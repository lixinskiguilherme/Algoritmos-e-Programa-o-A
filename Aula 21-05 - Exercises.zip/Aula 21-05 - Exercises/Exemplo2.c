#include <stdio.h>
#include <stdbool.h>

main(){
	int op, i;
	for(;true;){
		printf("Digite um valor para op: ");
		scanf("%i", &op);	
		printf("Op digitado: %i\n", op);
		if(op == 15){
			printf("Obrigado pela participacao");
			break;
		}
	}
	
}

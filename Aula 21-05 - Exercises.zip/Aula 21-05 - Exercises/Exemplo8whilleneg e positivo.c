#include <stdio.h>
#include <stdbool.h>

main(){
	int op, i;
	
	while(true){
		printf("Digite um valor para op: ");
		scanf("%i", &op);
		if(op == 0) {
            printf("Valor digitado e zero. O loop sera interrompido.\n");
            break;
    	}
		if(op >0 ){
				printf("%i e Positivo\n",op);
		}
			else{
		printf("%i e Negativo\n", op);
		}
		
		i++;
		
	}
	
}

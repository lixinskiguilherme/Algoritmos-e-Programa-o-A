#include <stdio.h>
#include <stdbool.h>

main(){
	int i;
	i = 0;
	while(i<=100){
		if(i%2==0){
			printf("Par: %i\n",i);
		}
			
		i++;
	}
	

}

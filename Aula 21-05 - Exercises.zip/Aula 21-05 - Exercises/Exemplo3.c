#include <stdio.h>
#include <stdbool.h>

main(){
	int i, j;
	for( i =0; i<20; i++){
		printf ("i vale %i\n", i);
		for(j = 0; j<4; j++){
			printf("	j vale %i\n", j);
		}
	}
	
}

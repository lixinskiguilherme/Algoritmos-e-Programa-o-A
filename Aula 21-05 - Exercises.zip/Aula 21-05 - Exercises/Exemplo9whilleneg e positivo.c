#include <stdio.h>
#include <stdbool.h>

main(){
	int op, i;
	
	do{
		printf("Digite um valor para op: ");
		scanf("%i", &op);
		if(op > 0) {
            printf("%i e Positivo\n",op);
		}
		else if(op<0){
			printf("%i e Negativo\n", op);
		}
	}
	while(op!=0);
	
}

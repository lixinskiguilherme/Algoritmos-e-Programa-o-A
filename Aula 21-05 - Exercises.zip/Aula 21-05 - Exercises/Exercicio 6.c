/*Escreva um algoritmo para ler um n�mero n e
 em seguida ler a idade de n pessoas pelo teclado. 
 Ap�s, calcular e apresentar a m�dia de idade das pessoas.*/

#include <stdio.h>
#include <stdbool.h>

main(){
	int n, i;
	float idade, total, media;
	total = 0;//sempre inicializar com o zero
	printf("Digite a quantidade de pessoas: ");
	scanf("%i", &n);
	for(i=1; i <= n; i++){
		printf("Digite a idade da pessoa %i: \n", i);
		scanf("%f", &idade);
		total = idade + total;
		
	}
	media = total / n;
	printf("Media = %.2f",media);	
	
}

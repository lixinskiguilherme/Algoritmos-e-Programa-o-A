#include <stdio.h>

main(){
	int n1, n2, n3;
	printf("Digite um numero: ");
	scanf("%i", &n1);
	printf("Digite um numero: ");
	scanf("%i", &n2);
	printf("Digite um numero: ");
	scanf("%i", &n3);
	if((n1>n2) && (n1>n3)){
		printf("N1 e o maior");
	}
	else if((n2>n1 && n2>n3)){
		printf("N2 e o maior");
	}
	else((n3>n1) && (n3>n2));{
		printf("N3 e o maior");
	}
	
	
}

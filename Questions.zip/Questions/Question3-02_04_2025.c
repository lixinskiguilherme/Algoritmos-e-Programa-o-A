#include <stdio.h>

main(){
	int n;
	printf("Digite um numero inteiro: ");
	scanf("%i", &n);
	//nao consegui conluir a interpresta��o.
	if(n%2==0){
		printf("O numero e: par");
	}
	else{
		printf("O numero e: impar");
	}
	getch();	
	
	
	
}

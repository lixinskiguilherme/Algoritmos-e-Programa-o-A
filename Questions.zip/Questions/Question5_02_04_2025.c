#include <stdio.h>

main(){
	int n1, n2, n3;
	printf("Digite um numero: ");
	scanf("%i", &n1);
	printf("Digite um numero: ");
	scanf("%i", &n2);
	printf("Digite um numero: ");
	scanf("%i", &n3);
	if(n1>n2 && n1>n3){
		if(n2<n3){
			printf("%i\n",n2);
			printf("%i\n",n3);
		}
		else if (n3<n2){
			printf("%i\n",n3);
			printf("%i\n",n2);
		}
		printf("%i",n1);
    }
    
	getch();
}

#include <stdio.h>

main(){
	int n1, n2;
	printf("Digite um numero: ");
	scanf("%i", &n1);
	printf("Digite um numero: ");
	scanf("%i", &n2);
	if(n1>n2){
		printf("O numero maior e: %i",n1);
	}
	else{
		printf("O numero maior e: %i",n2);
	}
	
	
}

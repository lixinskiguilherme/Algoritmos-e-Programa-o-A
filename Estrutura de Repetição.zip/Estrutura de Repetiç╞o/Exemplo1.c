#include <stdio.h>

main(){
	int i, in, f;
	printf("To write a number : ");
	scanf("%i", &in);
	printf("To write a number: ");
	scanf("%i", &f);
	if(in<f){
		for(i=in;i<=f;i++){
		printf("i vale %i\n", i);
		}
	}
	else{
		for(i=in;i>=f;i--){
		printf("i vale %i\n", i);
		}
	}
		printf("Final Instruction");
	
}

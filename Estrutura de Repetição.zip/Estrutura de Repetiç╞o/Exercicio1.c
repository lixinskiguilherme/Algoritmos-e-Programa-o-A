#include <stdio.h>

main(){
	int i, x;
	printf("To write a number repetition : ");
	scanf("%i", &x);
	for(i=0;i<=100;i++){
		if(i%x==0)
		printf("%i � divisivel por %i\n",i, x);
		}
	
		printf("Final Instruction");
	
}

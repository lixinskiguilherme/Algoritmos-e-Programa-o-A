#include <stdio.h>

main(){
	int i, n;
	printf("To write a number repetition : ");
	scanf("%i", &n);
	for(i=n;i<=100;i+=n){
		printf("i vale %i\n", i);
		}
	
		printf("Final Instruction");
	
}

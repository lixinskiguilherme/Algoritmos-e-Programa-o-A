#include <stdio.h>

main(){
	float n1, n2, r;
	char op;
	printf("Digite um numero n1: ");
	scanf("%f", &n1);
	printf("Digite um numero n2: ");
	scanf("%f", &n2);
	fflush(stdin);//limpa o buffer
	printf("Digite uma operacao: \n");
	printf("+ para somar\n");
	printf("- para subtrair\n");
	printf("/ para dividir\n");
	printf("x para multiplicar\n");
	scanf("%c", &op);
	printf("A operacao selecionada foi: %c\n",op);
	switch (op){
		case '+':
			r = n1+n2;
			printf("Soma: %f",r);
			break;
		case '-':
			r = n1-n2;
			printf("Subtracao: %f",r);
			break;
		case '/':
			r = n1/n2;
			printf("Divisao: %f",r);
			break;
		case 'x':
			r = n1*n2;
			printf("Multiplicacao: %f",r);
			break;
	}
	getch();
}

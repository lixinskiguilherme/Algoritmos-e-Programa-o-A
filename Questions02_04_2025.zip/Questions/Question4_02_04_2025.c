#include <stdio.h>

main(){
	int n1, n2, n3;
	printf("Digite um numero: ");
	scanf("%i", &n1);
	printf("Digite um numero: ");
	scanf("%i", &n2);
	printf("Digite um numero: ");
	scanf("%i", &n3);
	if(n1>n2 && n1>n3){
		printf("O numero maior e: %i",n1);
	}
	else if((n2>n1 && n2>n3)){
		printf("O numero maior e: %i",n2);
	}
	else{
		printf("O numero maior e: %i",n3);
	}
	
	
}

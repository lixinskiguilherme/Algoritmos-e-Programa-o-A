#include <stdio.h>

main(){
	int num,divisao;
	printf("Digite um numero inteiro: ");
	scanf("%i", &num);
	divisao=num/2;
	//nao consegui conluir a interpresta��o.
	printf("Resultado da divisao e: %i\n",divisao);
	if("num % 0"){
		printf("O numero e: par");
	}
	else{
		printf("O numero e: impar");
	}
	
	getch();	
	
	
	
}

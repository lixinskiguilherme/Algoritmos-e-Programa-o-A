#include <stdio.h>

main(){
	int n1, n2, n3;
	printf("Digite um numero: ");
	scanf("%i", &n1);
	printf("Digite um numero: ");
	scanf("%i", &n2);
	printf("Digite um numero: ");
	scanf("%i", &n3);
	if(n1<n2 && n1<n3){
		if(n2<n3);
		printf("%i - %i - %i",n1, n2, n3);
    }
    else if((n2<n1 && n2<n3)){
		if(n1<n3);
		printf("%i - %i - %i",n2, n1, n3);
		}
	else if(n3<n1 && n3<n2){
		if(n3<n1);
		printf("%i - %i - %i",n3, n1, n2);
		}
	getch();
}

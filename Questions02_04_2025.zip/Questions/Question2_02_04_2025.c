#include <stdio.h>

main(){
	float n1, n2, n3, soma, media, aprovado, reprovado;
	printf("Digite a primeira nota: ");
	scanf("%f",&n1);
	printf("Digite a segunda nota: ");
	scanf("%f",&n2);
	printf("Digite a terceira nota: ");
	scanf("%f",&n3);
	soma = n1+n2+n3;
	media = soma/3;
	printf("Media do semestre =%.2f\n",media);
	if(media>=6){
		printf("Aprovado");
	}
	else{
		printf("Reprovado");
	}
	
	
	getch();
}

#include <stdio.h>

main(){
	float nota1, peso1, nota2, peso2, nota3, peso3, media;
	printf("Digite a nota1: ");
	scanf("%f", &nota1);
	printf("Digite o peso1: ");
	scanf("%f", &peso1);
	printf("Digite a nota2: ");
	scanf("%f", &nota2);
	printf("Digite o peso2: ");
	scanf("%f", &peso2);
	printf("Digite a nota3: ");
	scanf("%f", &nota3);
	printf("Digite o peso3: ");
	scanf("%f", &peso3);
	media = ((nota1*peso1)+(nota2*peso2)+(nota3*peso3))/(peso1+peso2+peso3);
	printf("A media ponderada e de: %f", media);
	getch();
	
	
	
}

#include <stdio.h>

main(){
	float pv, dinheiro, troco;
	printf("Digite o valor do produto: ");
	scanf("%f", &pv);
	printf("Digite o valor em dinheiro: ");
	scanf("%f", &dinheiro);
	troco = dinheiro-pv;
	printf("O valor do troco a devolver ao cliente e de: %.2f", troco);
	getch();
	
	
	
}

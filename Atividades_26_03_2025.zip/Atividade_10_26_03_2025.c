#include <stdio.h>

main(){
	float frequencia, h_aulas, faltas, presencas;
	printf("Informe as horas aulas: ");
	scanf("%f", &h_aulas);
	printf("Informe o numero de presencas: ");
	scanf("%f", &presencas);
	frequencia = (presencas/h_aulas)*100;
	printf("A frequencia deste aluno foi de: %.2f %%", frequencia);
	getch();
}

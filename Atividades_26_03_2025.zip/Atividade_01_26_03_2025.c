#include <stdio.h>

main(){
	float n1, n2, total;
	printf("Digite a quantidade: ");
	scanf("%f", &n1);
	printf("Digite o valor unitario de cada produto: ");
	scanf("%f", &n2);
	total = (n1*n2);
	printf("O valor total da compra foi de: %f",total);
	getch();
	
	
	
}

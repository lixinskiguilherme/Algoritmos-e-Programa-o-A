#include <stdio.h>

main(){
	float km, numlitros, media;
	printf("Informe o numero de km percorridos: ");
	scanf("%f", &km);
	printf("Informe o numero de litros de combustivel abastecido: ");
	scanf("%f", &numlitros);
	media = km/numlitros;
	printf("Seu automovel fez uma media de: %.2f km por litro de combustivel", media);
	getch();
}

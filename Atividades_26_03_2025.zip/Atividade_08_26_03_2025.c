#include <stdio.h>

main(){
	float distancia, tempo, vmedia;
	printf("Informe a distancia percorrida em km: ");
	scanf("%f", &distancia);
	printf("Informe o tempo de duracao da viagem em horas: ");
	scanf("%f", &tempo);
	vmedia = distancia/tempo;
	printf("A velocidade m�dia de deslocamento foi de: %.2f km/hora", vmedia);
	getch();
}

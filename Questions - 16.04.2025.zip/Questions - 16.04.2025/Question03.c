#include <stdio.h>
#include <conio.h>

main(){
	int idade, voto;
	printf("Digite a idade do eleitor: ");
	scanf("%d", &idade);
	if(idade < 16){
		printf("Cidadao nao esta apto ao voto");
		}
	if((idade >=16) && (idade< 18) || (idade>=70)){
		printf("Cidadao o seu voto e facultativo");
	}
	if((idade >=18) && (idade <= 69)){
		printf("Seu voto e obrigatorio");
	}
	
}

#include <stdio.h>
#include <conio.h>

main(){
	float sal, aliquota, vir, vliquido;
	printf("Digite o valor do salario: ");
	scanf("%f", &sal);
	
	if(sal <= 3036.00){
		aliquota = 0;
		}
	if((sal > 3036.00) && (sal<= 3533.31)){
		aliquota = 7.5;
	}
	if((sal > 3533.31) && (sal<= 4688.85)){
		aliquota = 15;
	}
	if((sal > 4668.85) && (sal<= 5830.85)){
		aliquota = 22.5;
	}
    if(sal > 5830.85) {
		aliquota = 27.5;
	}	
	
	vir = sal*aliquota/100;
	vliquido = sal-vir;
	printf("O valor do salario atual e de: %.2f\n", sal);
	printf("O percentual do imposto de renda e de: %.2f\n", aliquota);
	printf("O valor da retencao do IR e de: %.2f\n", vir);
	printf("O valor liquido do salario apos a retencao e de: %.2f\n", vliquido);
}

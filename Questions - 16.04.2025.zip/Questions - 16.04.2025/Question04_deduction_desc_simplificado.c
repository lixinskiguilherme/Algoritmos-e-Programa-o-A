#include <stdio.h>
#include <conio.h>

main(){
	float sal, bcalc, dsimpl, aliquota, deducao, vir, vliquido;
	printf("Digite o valor do salario: ");
	scanf("%f", &sal);
	dsimpl = 607.20;
	bcalc = sal-dsimpl;
	
	if(bcalc <= 2428.80){
		aliquota = 0;
		}
	if((bcalc >= 2428.81) && (bcalc<= 2826.65)){
		aliquota = 7.50;
		deducao = 182.16;
	}
	if((bcalc >= 2826.66) && (bcalc<= 3751.05)){
		aliquota = 15;
		deducao = 394.16;
	}
	if((bcalc >= 3751.06) && (bcalc<= 4664.68)){
		aliquota = 22.50;
		deducao = 675.49;
	}
    if(bcalc > 4664.68) {
		aliquota = 27.50;
		deducao = 908.73;
	}	
	
	vir = (bcalc*aliquota/100)-deducao;
	vliquido = sal-vir;
	printf("O valor do salario atual e de: %.4f\n", sal);
	printf("O valor da base de calculo do IR e de: %.4f\n", bcalc);
	printf("O percentual do imposto de renda e de: %.4f\n", aliquota);
	printf("O valor da retencao do IR e de: %.4f\n", vir);
	printf("O valor liquido do salario apos a retencao e de: %.4f\n", vliquido);
}
